from django.shortcuts import render
from django.http import HttpResponse
from studentinfo.models import Studentdetails, Coursedetails, Studentenrollment
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def dashboard(request):
    request.session['username'] = request.user.username
    if request.session['username']:
        uname = request.session['username']

    cursorobj = connection.cursor()
    cursorobj.execute('SELECT COUNT(courseid) FROM studentinfo_coursedetails')
    coursecount = cursorobj.fetchone()
    coursecountvalue = coursecount[0]

    cursorobj = connection.cursor()
    cursorobj.execute('SELECT avg(gpa) from studentinfo_studentdetails')
    averagegpa = cursorobj.fetchone()
    averagegpavalue = averagegpa[0]

    cursorobj = connection.cursor()
    cursorobj.execute('SELECT COUNT(DISTINCT id) FROM studentinfo_studentenrollment')
    enrollcount = cursorobj.fetchone()
    enrollcountvalue = enrollcount[0]

    cursorobj = connection.cursor()
    cursorobj.execute('SELECT count(studentid) FROM studentinfo_studentdetails WHERE year = "Senior"')
    seniorcount = cursorobj.fetchone()
    seniorcountvalue = seniorcount[0]

    context = {'name' : uname, 'coursecount' : coursecountvalue, 'averagegpa' : averagegpavalue, 'enrollcount' : enrollcountvalue, 'seniorcount' : seniorcountvalue}

    return render(request, 'studentinfo/dashboard.html', context)

def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

@login_required
def studentdetails(request):
    print(request.META)
    studentdata = Studentdetails.objects.all()
    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context  = {'data' : minidata}
    return render(request, 'studentinfo/studentdetails.html', context)

@login_required
def coursedetails(request):
    print(request.META)
    coursedata = Coursedetails.objects.all()
    paginator = Paginator(coursedata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context  = {'data' : minidata}
    return render(request, 'studentinfo/coursedetails.html', context)

@login_required
def enrollstudent(request):
    studentdata = Studentdetails.objects.all()
    enrolldata = Studentenrollment.objects.all()
    coursedata = Coursedetails.objects.all()

    if 'student' in request.session:
        enrolldata = Studentenrollment.objects.filter(student = request.session['student'])

    context = {'studentdetails' : studentdata, 'enrollment' : enrolldata, 'coursedetails' : coursedata}
    return render(request, 'studentinfo/enrollment.html', context)

def saveenroll(request):
    if('sname' in request.GET and 'ctitle' not in request.GET):
        request.session['student'] = request.GET.get('sname')

    if('sname' and 'ctitle' in request.GET):
        studentname = request.GET.get('sname')
        courseinfo = request.GET.get('ctitle')
        dataobj = Studentenrollment(student=studentname, course=courseinfo)
        cursorobj = connection.cursor()
        cursorobj.execute('SELECT * from studentinfo_studentenrollment WHERE student= %s', [studentname])
        result = cursorobj.fetchall()
        print(result)
        print(len(result))
        if len(result) > 2:
            print("Student cannot enroll in more than 3 courses")
            return HttpResponse("Fail")
        if (any(courseinfo in i for i in result)):
            print("Student can only enroll in each course one time")
            return HttpResponse("Fail")
        else:
            dataobj.save()
    return HttpResponse("Success")
